<?php

class Kitchensink_IndexController extends Kms_Module_Controller_Abstract
{
    public function headerAction()
    {
        $request = Zend_Controller_Front::getInstance()->getRequest();
        $this->view->isExamplePage = $request->getModuleName() == Kitchensink_Model_Kitchensink::MODULE_NAME && $request->getActionName() == 'ds-page-example';
    }

    public function dsPageExampleAction() {}

    public function handleModalFormSubmitAction()
    {
        Kms_Helper_Controller_Json::sendJson($this->_helper, $this->getModalFormSubmitResult());
    }

    private function getModalFormSubmitResult()
    {
        $translator = Zend_Registry::get('Zend_Translate');
        $request = $this->getRequest();
        $requestDataArr = json_decode($request->getRawBody(), true);

        if (empty($requestDataArr)) {
            return [
                'status' => false,
                'message' => $translator->translate('Request info is empty'),
            ];
        }

        $status = rand(0, 1); // Random status

        return [
            'status' => (bool) $status,
            'message' => $status ? $translator->translate('Got this values: ') . implode(', ', $requestDataArr) : $translator->translate('Error from server'),
        ];
    }
}
