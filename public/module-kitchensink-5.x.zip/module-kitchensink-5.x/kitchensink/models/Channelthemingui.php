<?php

/**
 * Channelthemingui_Model_Interface_ChannelTabComponents - Used to add tabs to channel page
 */
class Kitchensink_Model_Channelthemingui implements Channelthemingui_Model_Interface_ChannelTabComponents
{
    /**
     * @inheritDoc
     *
     * @see Channelthemingui_Model_Interface_ChannelTabComponents::modifyChannelTabComponents()
     */
    public function modifyChannelTabComponents(Kaltura_Client_Type_Category $category, array $channelTabComponents): array
    {
        /** @var Kms_Translate $translator */
        $translator = Zend_Registry::get('Zend_Translate');

        return [new Kms_Type_ChannelTabComponent(
            'kApps.Kitchensink.TabContent',
            [],
            $translator->translate('Tab Example')
        )];
    }
}
