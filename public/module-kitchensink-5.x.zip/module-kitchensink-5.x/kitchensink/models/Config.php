<?php

class Kitchensink_Model_Config
{
    public const MODULE_NAME = Kitchensink_Model_Kitchensink::MODULE_NAME;

    public static function getActionMenuModalLabelName(): string
    {
        /** @var Kms_Translate $translator */
        $translator = Zend_Registry::get('Zend_Translate');

        return $translator->translate(Kms_Resource_Config::getModuleConfig(self::MODULE_NAME, 'actionMenuModalLabelName'));
    }

    public static function getActionMenuLinkLabelName(): string
    {
        /** @var Kms_Translate $translator */
        $translator = Zend_Registry::get('Zend_Translate');

        return $translator->translate(Kms_Resource_Config::getModuleConfig(self::MODULE_NAME, 'actionMenuLinkLabelName'));
    }

    public static function getDisplayLayoutPopup(): bool
    {
        return Kms_Resource_Config::isBooleanFieldTrue(self::MODULE_NAME, 'displayLayoutPopup', true);
    }
}
