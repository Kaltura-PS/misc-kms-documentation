<?php

/**
 * Kms_Interface_FrontendTranslations - Used to add translations to the React app page
 * Kms_Interface_Functional_Media_Title_GetMenuItems - Used to add menu item(s) into actions menu in media/entry page
 * Kms_Interface_Functional_Media_Title_GetButtons - Used to add button(s) to actions area in media/entry page
 * Kms_Interface_Functional_Media_Metadata - Used to add metadata in media/entry page
 * Kms_Interface_Functional_Layout_DsLayoutItems - Add DS layout to any page
 */
class Kitchensink_Model_Kitchensink extends Kms_Module_BaseModel implements
    Kms_Interface_Module_Interface,
    Kms_Interface_FrontendTranslations,
    Kms_Interface_Functional_Media_Title_GetMenuItems,
    Kms_Interface_Functional_Media_Title_GetButtons,
    Kms_Interface_Functional_Media_Metadata,
    Kms_Interface_Functional_Layout_DsLayoutItems,
    Kms_Interface_Form_Media_Edit
{
    use Kms_Functional_Layout_DsLayoutItemsTrait;

    public const MODULE_NAME = 'kitchensink';

    public $viewHooks = [
        Kms_Resource_Viewhook::CORE_VIEW_HOOK_MODULES_HEADER => [
            'controller' => 'index',
            'action' => 'header',
            'order' => '20',
        ],
    ];

    private $_interfaceImplementing = [
        'Personalprofile_Model_Interface_Tabs' => 'Kitchensink_Model_Personalprofile',
        'Channelthemingui_Model_Interface_ChannelTabComponents' => 'Kitchensink_Model_Channelthemingui',
        'Uploadmedia_Model_Interface_EditForm' => 'Kitchensink_Model_Uploadmedia',
    ];

    public function getAccessRules()
    {
        return [
            [
                'controller' => self::MODULE_NAME . ':index',
                'actions' => ['header', 'handle-modal-form-submit'],
                'role' => Kms_Plugin_Access::EMPTY_ROLE,
            ],
            [
                'controller' => self::MODULE_NAME . ':index',
                'actions' => ['ds-page-example'],
                'role' => Kms_Plugin_Access::VIEWER_ROLE,
            ],
        ];
    }

    /**
     * @return array of module interfaces that are being implemented by a delegate
     */
    public function getInterfacesImplemented()
    {
        return array_keys($this->_interfaceImplementing);
    }

    /**
     * @param $interfaceName - the module interface that is needed to be implemented
     *
     * @return object - a class which is implementing the $interfaceName interface
     */
    public function getInterfaceImplementingObject($interfaceName)
    {
        $implementingClassName = $this->_interfaceImplementing[$interfaceName];

        return new $implementingClassName();
    }

    /**
     * Return array with texts that are hardcoded in the React app
     *
     * @inheritDoc
     *
     * @see Kms_Interface_FrontendTranslations::getFrontendTranslations()
     */
    public function getFrontendTranslations($view): array
    {
        return [
            'Some Info Message' => $view->translate('Some Info Message'),
            'Select elements' => $view->translate('Select elements'),
            'Submitted Successfully' => $view->translate('Submitted Successfully'),
            'Lorem Ipsum is simply dummy text of printing presses and text files' => $view->translate('Lorem Ipsum is simply dummy text of printing presses and text files'),
        ];
    }

    /**
     * @inheritDoc
     *
     * @see Kms_Interface_Functional_Media_Title_GetMenuItems::getMediaTitleMenuItems()
     */
    public function getMediaTitleMenuItems(Kms_Type_Media_Page_Props $props): array
    {
        return [
            $this->getMenuItemModalComponent($props),
            $this->getMenuItemLink(),
        ];
    }

    /**
     * @inheritDoc
     *
     * @see Kms_Interface_Functional_Media_Title_GetButtons::getMediaTitleButtons()
     */
    public function getMediaTitleButtons(Kms_Type_Media_Page_Props $props): array
    {
        /** @var Kms_Translate $translator */
        $translator = Zend_Registry::get('Zend_Translate');

        return [
            new Kms_Type_Component('kApps.Kitchensink.MediaButton', ['buttonText' => $translator->translate('Button Example')]),
        ];
    }

    /**
     * @inheritDoc
     */
    public function getMediaMetadata(Kms_Type_Media_Page_Props $params)
    {
        /** @var Kms_Translate $translator */
        $translator = Zend_Registry::get('Zend_Translate');

        // Example for Mediaspace CustomMetadataLine component - Allowed to add label with values
        $components[] = new Kms_Type_Component(
            'MEDIASPACE.MediaPage.CustomMetadataLine',
            [
                'label' => $translator->translate('Label Name'),
                'items' => [
                    [
                        'label' => $translator->translate('text 1'),
                    ],
                    [
                        'label' => $translator->translate('text url'),
                        'url' => 'https://google.com', // If you want the text will be clickable add url link
                    ],
                ],
                'paragraphs' => false,
            ],
            120,
        );

        // Example for PS component
        $components[] = new Kms_Type_Component(
            'kApps.Kitchensink.CustomMetadata',
            [],
            130,
        );

        return $components;
    }

    /**
     * @inheritDoc
     *
     * @see Kms_Interface_Functional_Layout_DsLayoutItems::getDsLayoutItems()
     */
    public function getDsLayoutItems(): array
    {
        if (Kitchensink_Model_Config::getDisplayLayoutPopup()) {
            return [
                new Kms_Type_Layout_RegionComponent(
                    Kms_Type_Layout_RegionEnum::FLOATED,
                    'kApps.Kitchensink.ModalLayout',
                ),
            ];
        }

        return [];
    }

    /**
     * @inheritDoc
     *
     * @see Kms_Interface_Form_Media_Edit::getMediaEditFormElements()
     */
    public function getMediaEditFormElements(): array
    {
        $textElement = new Kms_Type_Media_EditFormElement();
        $textElement->showOn = Kms_Type_Media_EditFormElement_ShowOn::BOTH; // Edit-form fields can be available when editing a single entry, when editing bulk, or on both cases.
        $textElement->id = 'textField';
        $textElement->label = 'Text Field Test';
        $textElement->description = 'This is description of the field';
        $textElement->belongsTo = Kitchensink_Model_Kitchensink::MODULE_NAME; // Set module name
        $textElement->requiredForPublish = true; // boolean - should the field have a saved value before publishing the ent
        $textElement->required = true; // boolean - if field is required
        $textElement->fieldType = Kms_Type_Media_EditFormElement_FieldType::TEXT_ELEMENT;

        $selectElement = new Kms_Type_Media_EditFormElement();
        $selectElement->showOn = Kms_Type_Media_EditFormElement_ShowOn::BOTH; // Edit-form fields can be available when editing a single entry, when editing bulk, or on both cases.
        $selectElement->id = 'selectField';
        $selectElement->label = 'Select Field Test';
        $selectElement->options = [
            'Item 1',
            'Item 2',
            'Item 3',
        ];
        $selectElement->belongsTo = Kitchensink_Model_Kitchensink::MODULE_NAME; // Set module name
        $selectElement->fieldType = Kms_Type_Media_EditFormElement_FieldType::LIST_ELEMENT;

        $mediaEditFormElementsArr[] = $textElement;
        $mediaEditFormElementsArr[] = $selectElement;

        return $mediaEditFormElementsArr;
    }

    /**
     * @inheritDoc
     *
     * @see Kms_Interface_Form_Media_Edit::saveMediaEditFormData()
     */
    public function saveMediaEditFormData(array $entryIds, array $data)
    {
        exit('<pre>' . print_r([$entryIds, $data, __FILE__, __LINE__], true) . '</pre>');
        /*
         * There you need to save the data you get from the upload/edit media form.
         * The elements that you added will be received in this format:
         * [MODULE_NAME] => [
         *      [FIELD_ID] => VALUE
         *      ...
         * ]
         */

        return [];
    }

    private function getMenuItemModalComponent(Kms_Type_Media_Page_Props $props): Kms_Type_Component
    {
        for ($i = 1; $i <= 5; ++$i) {
            $multiSelectValuesArr[] = [
                'value' => "item{$i}",
                'title' => "Item {$i}",
            ];
        }

        $modalLabelName = Kitchensink_Model_Config::getActionMenuModalLabelName();
        $modalExampleComponent = new Kms_Type_Component('kApps.Kitchensink.ModalExample');
        $modalExampleComponent->props = [
            'label' => $modalLabelName,
            'entryId' => $props->entry->id,
            'multiSelectValues' => $multiSelectValuesArr,
        ];
        $modalExampleComponent->name = $modalLabelName;
        $modalExampleComponent->order = 50;

        return $modalExampleComponent;
    }

    private function getMenuItemLink(): Kms_Type_Component
    {
        $view = new Zend_View_Helper_BaseUrl();
        $linkMenuItem = new Kms_Type_Component('MEDIASPACE.MediaActions.Items.LinkMenuItem');
        $linkMenuItem->props = [
            'label' => Kitchensink_Model_Config::getActionMenuLinkLabelName(),
            'href' => $view->baseUrl('/ds-page-example'),
        ];
        $linkMenuItem->order = 51;

        return $linkMenuItem;
    }
}
