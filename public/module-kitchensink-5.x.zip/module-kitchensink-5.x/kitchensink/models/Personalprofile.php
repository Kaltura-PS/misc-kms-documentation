<?php

/**
 * Personalprofile_Model_Interface_Tabs - Used to add tabs to profile page
 */
class Kitchensink_Model_Personalprofile implements Personalprofile_Model_Interface_Tabs
{
    /**
     * @inheritDoc
     *
     * @see Personalprofile_Model_Interface_Tabs::getPersonalProfileTabs
     */
    public function getPersonalProfileTabs($userId, $activeTab = null): array
    {
        /** @var Kms_Translate $translator */
        $translator = Zend_Registry::get('Zend_Translate');
        $componentName = 'TabContent';

        return [new Kms_Type_Tab_Component(
            $translator->translate('Tab Example'),
            "kApps.Kitchensink.{$componentName}",
            [],
            30,
            $activeTab === $componentName
        )];
    }
}
