/*
 * ATTENTION!
 * Please don't modify this file manually, it was created automatically by a CLI tool!
 * Customizations could be done in ../../vite.config.ts
 */

import { UserConfig } from "vite";
import { resolve } from "path";
import react from "@vitejs/plugin-react";
import deepMerge from "deepmerge";

// https://vitejs.dev/config/
export const kmsViteConfig = (moduleName: string, config: UserConfig = {}) =>
    deepMerge(
        {
            build: {
                lib: {
                    entry: resolve(__dirname, "../App.tsx"),
                    name: `kApps.${moduleName}`,
                    formats: ["umd"],
                    fileName: () => "app.js",
                },
                outDir: resolve(__dirname, "../../..", moduleName.toLowerCase(), "assets"),
                emptyOutDir: false,
                rollupOptions: {
                    external: [
                        "react",
                        "react-dom",
                        "react-dom/server",
                        "react-dom/client",
                        "@mui/material",
                        "@emotion/styled",
                        "@emotion/react",
                        "styled-components",
                    ],
                    output: {
                        globals: {
                            react: "MEDIASPACE.React",
                            "react-dom": "MEDIASPACE.ReactDOM",
                            "react-dom/server": "MEDIASPACE.ReactDOMServer",
                            "react-dom/client": "MEDIASPACE.ReactDOMClient",
                            "@mui/material": "MEDIASPACE.MuiMaterial",
                            "@emotion/styled": "MEDIASPACE.EmotionStyled",
                            "@emotion/react": "MEDIASPACE.EmotionReact",
                            "styled-components": "MEDIASPACE.StyledComponents",
                        },
                    },
                },
            },
            define: {
                "process.env.NODE_ENV": `"${process.env.NODE_ENV}"`,
            },
            plugins: [react()],
        },
        config
    );
