/*
 * ATTENTION!
 * Please don't modify this file manually, it was created automatically by a CLI tool!
 * Customizations could be done in ../../.storybook/preview.ts
 */

import type { Decorator, Preview } from "@storybook/react";
import { css, Global } from "@emotion/react";
import { ThemeProvider } from "@kaltura/ds-react-theme";
import deepMerge from "deepmerge";

const globalStyles = () => css``;

const withThemeProvider: Decorator = (Story, { globals }) => {
    return (
        <>
            <Global styles={globalStyles} />
            <ThemeProvider overrides={{ mode: globals.themePalette }}>
                <Story />
            </ThemeProvider>
        </>
    );
};

export const modifyStorybookPreview = (preview: Preview) =>
    deepMerge(
        preview,
        {
            globalTypes: {
                themePalette: {
                    name: "themePalette",
                    description: "Theme palette to be used",
                    defaultValue: "light",
                    toolbar: {
                        icon: "cog",
                        items: [
                            { value: "light", title: "Light" },
                            { value: "dark", title: "Dark" },
                        ],
                    },
                },
            },
            decorators: [withThemeProvider],
        }
    );
