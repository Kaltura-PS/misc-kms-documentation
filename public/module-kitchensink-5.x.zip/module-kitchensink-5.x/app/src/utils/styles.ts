import { styled } from "@mui/material";
import { Modal, modalClasses } from "@kaltura/ds-react-components";

export const StyledModal = styled(Modal)(({ theme }) => ({
    [`& .${modalClasses.paper}`]: {
        minWidth: 790,
        [theme.breakpoints.down(theme.breakpoints.values.lg)]: {
            minWidth: 790,
        },
        [theme.breakpoints.down(theme.breakpoints.values.md)]: {
            minWidth: 750,
        },
        [theme.breakpoints.down(767)]: { //this breakpoints not exist in theme (tablet)
            minWidth: 600,
        },
        [theme.breakpoints.down(theme.breakpoints.values.sm)]: {
            minWidth: "100%"
        },
    }
}));