import { baseUrl } from "@kaltura/mediaspace-shared-utils";

export const doApiRequest = async (endPoint: string, data?: any) => {
    let error = "";
    const apiUrl = `${baseUrl}/${endPoint}`;
    const result: { status: boolean; response?: any; error?: string } = {
        status: true,
    };
    const body = data ? data : {};
    const options = {
        method: "POST",
        body: JSON.stringify(body),
    };

    try {
        const apiResult = await fetch(apiUrl, options);
        const response = await apiResult.json();
        
        if (response && response.status) {
            result.response = response;
            return result;
        } else {
            error = response.message;
        }
    } catch (err: unknown) {
        console.log(`API Error: ${err}`);
        error = "An error occurred";
    }

    if (error) {
        result.status = false;
        result.error = error;
    }

    return result;
};
