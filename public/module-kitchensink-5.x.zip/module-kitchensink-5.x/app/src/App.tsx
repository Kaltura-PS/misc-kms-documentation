import { ExamplePage } from "./components/ExamplePage/ExamplePage";

export { ModalExample } from "./components/ModalExample/ModalExample";
export { MediaButton } from "./components/MediaButton/MediaButton";
export { ModalLayout } from "./components/ModalLayout/ModalLayout";
export { TabContent } from "./components/TabContent/TabContent";
export { CustomMetadata } from "./components/CustomMetadata/CustomMetadata";

export const App = () => {
    return (
        <>
            <ExamplePage />
        </>
    );
}
