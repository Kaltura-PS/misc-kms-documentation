import { type ToastOptions, type ToastsContextValue } from "@kaltura/mediaspace-shared-contexts";

declare global {
    interface Window {
        MEDIASPACE?: {
            UI?: {
                useToastsContext: () => ToastsContextValue;
            };
        };
    }
}

const defaultShowToast = () => {
    return {
        showToast: (options: ToastOptions) => {
            console.warn("showToast is not available in storybook. Toast message:", options.message);
        },
    };
};

export const useKmsToast = () => {
    const { showToast } = window.MEDIASPACE?.UI?.useToastsContext() || defaultShowToast();

    return {
        showToast,
    };
};
