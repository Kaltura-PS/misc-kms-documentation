import type { Meta, StoryObj } from "@storybook/react";
import { App } from "./App";

const meta: Meta<typeof App> = {
    component: App,
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {
    args: {
        label: "Modal Example",
        entryId: "1_6xg6co00",
        multiSelectValues: {
            display: true,
            values: [
                {
                    value: "item1",
                    title: "item 1"
                },
                {
                    value: "item2",
                    title: "item 2"
                },
                {
                    value: "item3",
                    title: "item 3"
                },
                {
                    value: "item4",
                    title: "item 4"
                },
                {
                    value: "item5",
                    title: "item 5"
                },
            ]
        },
    },
};
