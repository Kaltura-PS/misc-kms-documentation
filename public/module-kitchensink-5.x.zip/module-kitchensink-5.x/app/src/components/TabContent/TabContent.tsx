import { Box } from "@kaltura/mediaspace-shared-styled";
import { translate } from "@kaltura/mediaspace-shared-utils";
import { Typography } from "@kaltura/ds-react-components";

export const TabContent = () => {
    return (
        <Box>
            <Typography variant="body2Highlight">{translate("Tab Tile")}</Typography>
            <Typography variant="body2">{translate("Tab Content")}</Typography>
        </Box>
    )
}