import { Button } from "@kaltura/ds-react-components";
import { translate } from "@kaltura/mediaspace-shared-utils";
import { useKmsToast } from "../../hooks/useKmsToast";

interface ButtonProps {
    buttonText: string,
}

export const MediaButton = ({
    buttonText,
}: ButtonProps) => {
    const { showToast } = useKmsToast();

    const handleOnClick = () => {
        showToast({
            message: translate("Button Clicked"),
            severity: "info",
        });
    }

    return (
        <Button onClick={handleOnClick}>
            {buttonText}
        </Button>
    )
}