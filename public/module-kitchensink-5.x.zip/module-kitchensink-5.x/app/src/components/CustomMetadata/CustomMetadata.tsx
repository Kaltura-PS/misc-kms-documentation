import { styled } from "@mui/material";
import { Box } from "@kaltura/mediaspace-shared-styled";
import { translate } from "@kaltura/mediaspace-shared-utils";
import { Tag, Typography } from "@kaltura/ds-react-components";

const CustomMetadataContainer = styled(Box)({
    marginTop: 20,
});

const TagsWrapper = styled(Box)({
    display: "flex",
    gap: "5px",
    marginTop: 10,
});

export const CustomMetadata = () => {
    return (
        <CustomMetadataContainer>
            <Typography>
                {translate("Example to PS custom metadata")}
            </Typography>
            <TagsWrapper>
                <Tag
                    label={translate("Custom Metadata Text 1")}
                />
                <Tag
                    label={translate("Custom Metadata Text 2")}
                />
                <Tag
                    label={translate("Custom Metadata Text 3")}
                />
            </TagsWrapper>
        </CustomMetadataContainer>
    );
}