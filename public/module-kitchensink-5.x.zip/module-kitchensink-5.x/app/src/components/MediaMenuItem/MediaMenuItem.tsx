import { MenuItem } from "@kaltura/ds-react-components";

export interface MediaMenuItemProps {
    label: string;
    onClick: (openModal: boolean) => void;
}

export const MediaMenuItem = (props: MediaMenuItemProps) => {
    const { label, onClick } = props;

    return (
        <MenuItem
            onClick={() => { onClick(true) }}
            autoFocus={false}
        >
            {label}
        </MenuItem>
    );
}