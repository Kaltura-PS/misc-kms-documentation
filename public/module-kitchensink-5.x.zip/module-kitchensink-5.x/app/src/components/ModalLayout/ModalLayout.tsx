import { useState } from "react";

import { translate } from "@kaltura/mediaspace-shared-utils";
import { ModalContent, ModalTitle } from "@kaltura/ds-react-components";
import { StyledModal } from "../../utils/styles";

export const ModalLayout = () => {
    const [showModal, setShowModal] = useState<boolean>(true);

    return (
        <StyledModal open={showModal}>
            {/*In case you don't want it will have X button to close the modal, then remove: closeButtonAriaLabel and onClose*/}
            <ModalTitle closeButtonAriaLabel={translate("Close")} onClose={() => { setShowModal(false) }}>
                {translate("Modal Layout Title")}
            </ModalTitle>
            <ModalContent>
                {translate("Modal Layout Content")}
            </ModalContent>
        </StyledModal>
    );
}