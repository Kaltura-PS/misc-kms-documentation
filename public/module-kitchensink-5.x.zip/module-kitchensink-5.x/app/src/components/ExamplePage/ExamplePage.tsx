import styled from "@emotion/styled";

import { systemWidth, useTheme } from "@kaltura/mediaspace-shared-styled"
import { translate } from "@kaltura/mediaspace-shared-utils"
import { Typography } from "@mui/material";

const SystemWidth = styled.div(({ theme }) => ({
    "&": systemWidth({ theme }),
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    maxWidth: 650,
    paddingTop: 120,
    paddingBottom: 120,
    textAlign: "center",
}));

export const ExamplePage = () => {
    const theme = useTheme();

    return (
        <SystemWidth>
            <svg xmlns="http://www.w3.org/2000/svg" width="201" height="201" viewBox="0 0 201 201" fill="none">
                <rect x="36.6542" y="21.4292" width="63.3475" height="117.26" rx="31.6738" stroke={theme.kaltura.palette.tone1} />
                <rect x="20.5" y="106.147" width="95.6518" height="74.7823" rx="8" fill={theme.kaltura.palette.primary.main} />
                <path fill-rule="evenodd" clip-rule="evenodd" d="M59.9859 149.387C62.3457 148.274 63.9787 145.874 63.9787 143.092C63.9787 139.25 60.8641 136.135 57.0222 136.135C53.1802 136.135 50.0657 139.25 50.0657 143.092C50.0657 145.873 51.6982 148.274 54.0574 149.387L50.4981 161.403C50.282 162.133 50.8288 162.865 51.5898 162.865H62.4534C63.2144 162.865 63.7612 162.133 63.5451 161.403L59.9859 149.387Z" fill={theme.kaltura.palette.tone1} />
                <rect x="20.5" y="120.059" width="95.6518" height="0.869562" fill={theme.kaltura.palette.tone8} />
                <path fill-rule="evenodd" clip-rule="evenodd" d="M121.369 90.4944C121.369 81.85 128.376 74.8423 137.021 74.8423V74.8423C145.665 74.8423 152.673 81.85 152.673 90.4944V90.4944C152.673 99.1388 145.665 106.147 137.021 106.147V106.147C128.376 106.147 121.369 99.1388 121.369 90.4944V90.4944Z" fill={theme.kaltura.palette.tone1} />
                <path d="M131.76 96.5807L141.954 85.2764" stroke={theme.kaltura.palette.tone8} stroke-linecap="round" stroke-linejoin="round" />
                <path d="M142.51 96.0254L131.205 85.8316" stroke={theme.kaltura.palette.tone8} stroke-linecap="round" stroke-linejoin="round" />
                <ellipse cx="157.631" cy="144.129" rx="22.871" ry="23.2" fill={theme.kaltura.palette.tone3} />
                <ellipse cx="164.409" cy="144.129" rx="3.3883" ry="3.43704" fill={theme.kaltura.palette.tone8} />
                <path d="M175.769 144.129C175.769 154.3 167.643 162.533 157.634 162.533C147.624 162.533 139.498 154.3 139.498 144.129C139.498 133.958 147.624 125.725 157.634 125.725C167.643 125.725 175.769 133.958 175.769 144.129Z" stroke={theme.kaltura.palette.tone8} />
                <path d="M98.3353 139.19C99.8552 137.417 102.074 136.396 104.409 136.396H138.148V149.935C138.148 151 137.285 151.863 136.219 151.863H104.409C102.074 151.863 99.8552 150.843 98.3353 149.07L95.2161 145.432C94.5739 144.683 94.5739 143.577 95.2161 142.828L98.3353 139.19Z" fill={theme.kaltura.palette.tone3} />
                <path d="M104.265 144.742C105.958 142.876 109.192 142.157 111.742 143.08C113.038 143.549 114.156 144.387 115.534 144.634C117.029 144.902 118.549 144.43 120.02 144.08C121.513 143.724 123.065 143.488 124.611 143.581C125.894 143.659 127.14 143.961 128.394 144.203C131.203 144.745 133.704 144.623 138.908 144.43" stroke={theme.kaltura.palette.tone8} stroke-miterlimit="10" stroke-linecap="round" />
            </svg>
            <Typography variant={"h2"}>{translate("Lorem Ipsum is simply dummy text of printing presses and text files")}</Typography>
            <Typography variant={"body2"}>{translate("Lorem Ipsum is essentially the typeset and printing industry's dummy text. Since an unidentified printer jumbled a galley of type to create a type specimen book in the 1500s, Lorem Ipsum has been the industry standard sham text. It is virtually intact, having withstood not just five centuries but also the transition to electronic typesetting. The introduction of Letraset sheets with sections from Lorem Ipsum in the 1960s and, more recently, the inclusion of Lorem Ipsum versions in desktop publishing programs like Aldus PageMaker contributed to its popularization.")}</Typography>
        </SystemWidth>
    );
}