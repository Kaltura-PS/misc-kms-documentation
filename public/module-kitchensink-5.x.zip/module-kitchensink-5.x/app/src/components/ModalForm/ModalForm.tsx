import { useState } from "react";

import styled from "@emotion/styled";
import { Box, SelectChangeEvent, Typography } from "@mui/material";
import { BaseInput, Button, Checkbox, FormLabel, MenuItem, Select } from "@kaltura/ds-react-components";

import { MultiSelectValue } from "../../utils/types";
import { translate } from "@kaltura/mediaspace-shared-utils";

export interface FormProps {
    multiSelectValues: MultiSelectValue[];
    isAllowedToSubmitForm: boolean;
    inProgress: boolean;
    onSubmit: (generateLinkData: string[] | undefined) => void;
}

const Spacer = styled(Box)(({ theme }) => ({
    height: theme.spacing(3),
}));

const FullWidthElement = styled(Box)({
    width: "100%",

    ".multi-select-page-elements": {
        width: "100%",
    },
});

const AUTOCOMPLETE_ELEMENT_PLACEHOLDER = translate("Select elements");

export const ModalForm = ({
    isAllowedToSubmitForm,
    inProgress,
    multiSelectValues,
    onSubmit,
}: FormProps) => {
    const [selectedMultiValues, setSelectedMultiValues] = useState<string[]>([AUTOCOMPLETE_ELEMENT_PLACEHOLDER]);

    const handleMultiSelectChange = (event: SelectChangeEvent<typeof selectedMultiValues>) => {
        const {
            target: { value: selectedValues },
        } = event;

        let newValues: string[] = [];

        if (Array.isArray(selectedValues)) {
            //Check if array contains placeholder, if yes remove it
            const index = selectedValues.indexOf(AUTOCOMPLETE_ELEMENT_PLACEHOLDER);

            if (index > -1) {
                selectedValues.splice(index, 1);
            }

            newValues = selectedValues;
        }

        //If there is no selected values, add placeholder value
        if (newValues.length === 0) {
            newValues = [AUTOCOMPLETE_ELEMENT_PLACEHOLDER];
        }

        setSelectedMultiValues(newValues);
    };

    const handleGenerateElementClick = () => {
        let fromValues;

        if (multiSelectValues.length > 0 && selectedMultiValues) {
            //Get the values from the selected elements enforced
            if (selectedMultiValues.length) {
                fromValues = multiSelectValues
                    .filter((multiSelectValue) => selectedMultiValues.indexOf(multiSelectValue.title) > -1)
                    .map((multiSelectValue) => multiSelectValue.value);
            }
        }

        onSubmit(fromValues);
    };

    return (
        <>
            {multiSelectValues.length > 0 &&
                <FullWidthElement>
                    <FormLabel label={translate("Multi Select")} controlID="multi-select-form-elements" />
                    <Select
                        id="multi-select-form-elements"
                        className="multi-select-page-elements"
                        multiple
                        native={false}
                        value={selectedMultiValues}
                        onChange={handleMultiSelectChange}
                        input={<BaseInput />}
                        renderValue={(value) => value.join(", ")}
                    >
                        {multiSelectValues.map((multiSelectValues) => (
                            <MenuItem key={multiSelectValues.title} value={multiSelectValues.title}>
                                <div
                                    style={{
                                        display: "flex",
                                        gap: "10px",
                                    }}
                                >
                                    <Checkbox checked={selectedMultiValues.indexOf(multiSelectValues.title) > -1} />
                                    <Typography>{multiSelectValues.title}</Typography>
                                </div>
                            </MenuItem>
                        ))}
                    </Select>
                </FullWidthElement>
            }
            <Spacer />
            <Button onClick={handleGenerateElementClick} disabled={!isAllowedToSubmitForm} loading={inProgress}>
                {translate("Submit")}
            </Button>
        </>
    );
};
