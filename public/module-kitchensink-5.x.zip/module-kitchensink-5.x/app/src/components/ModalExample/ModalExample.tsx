import { useState } from "react";

import { styled } from "@mui/material";
import { Info24Icon } from "@kaltura/ds-react-icons";
import { translate } from "@kaltura/mediaspace-shared-utils";
import { Box } from "@kaltura/mediaspace-shared-styled";
import { Alert, ModalContent, ModalTitle, Typography } from "@kaltura/ds-react-components";

import { MediaMenuItem } from "../MediaMenuItem/MediaMenuItem";
import { ModalForm } from "../ModalForm/ModalForm";
import { doApiRequest } from "../../utils/utils";
import { StyledModal } from "../../utils/styles";
import { useKmsToast } from "../../hooks/useKmsToast";
import { MultiSelectValue } from "../../utils/types";

const StyledAlertWrapper = styled(Box)(({ theme }) => ({
    marginBottom: theme.spacing(2),
}));

const StyledFormContainer = styled(Box)(({ theme }) => ({
    minWidth: 350,
    [theme.breakpoints.down(theme.breakpoints.values.sm)]: {
        minWidth: "100%"
    }
}));

const Spacer = styled(Box)(({ theme }) => ({
    height: theme.spacing(3)
}));

export interface ModalProps {
    label: string;
    entryId: string;
    multiSelectValues: MultiSelectValue[];
}

export const ModalExample = ({
    entryId,
    label,
    multiSelectValues,
}: ModalProps) => {
    const [showModal, setShowModal] = useState<boolean>(false);
    const [isAllowedToSubmitForm, setIsAllowedToSubmitForm] = useState<boolean>(true);
    const [formSubmitInProgress, setFormSubmitInProgress] = useState<boolean>(false);
    const { showToast } = useKmsToast();

    const handleFormSubmit = async (formValues: string[] | undefined) => {
        console.log(formValues);

        setIsAllowedToSubmitForm(false);
        setFormSubmitInProgress(true);

        const result = await doApiRequest(`kitchensink/index/handle-modal-form-submit/entryId/${entryId}`, formValues);
        const message = result.error ? result.error : result.response.message;

        showToast({
            message: message,
            severity: result.status ? "success" : "error",
        });

        setFormSubmitInProgress(false);
        setIsAllowedToSubmitForm(true);
    };

    return (
        <>
            <MediaMenuItem label={label} onClick={setShowModal} />
            <StyledModal open={showModal}>
                {/*In case you don't want it will have X button to close the modal, then remove: closeButtonAriaLabel and onClose*/}
                <ModalTitle closeButtonAriaLabel={translate("Close")} onClose={() => { setShowModal(false) }}>
                    {label}
                </ModalTitle>
                <ModalContent>
                    <StyledAlertWrapper>
                        {/* severity can be one of this values - success, info, warning, error */}
                        <Alert severity={"info"} icon={<Info24Icon />} >
                            <Typography variant={"body2"}>
                                {translate("Some Info Message")}
                            </Typography>
                        </Alert>
                    </StyledAlertWrapper>
                    <StyledFormContainer>
                        <ModalForm
                            multiSelectValues={multiSelectValues}
                            isAllowedToSubmitForm={isAllowedToSubmitForm && !formSubmitInProgress}
                            inProgress={formSubmitInProgress}
                            onSubmit={handleFormSubmit}
                        />
                    </StyledFormContainer>
                    <Spacer />
                </ModalContent>
            </StyledModal>
        </>
    );
}