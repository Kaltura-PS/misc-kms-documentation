# Kitchensink UI components

UI components for the module, using React + TypeScript + Vite + MUI, based on Design System components.

Project was created with `mrc ` command from `mediaspace-react-components`, and the same command should be used to upgrade the project in case of changes.

## Building the bundle

Run `npm run build`.
It will compile the `src/App.tsx` file into a JavaScript file that could be used in the browser,
and place it into the `assets` folder as `app.js`.

## Including the bundle on the page

The script should be included on the page **after** including the core MediaSpace React components bundle:
```php
$this->appendAfterKmsComponentsHeadScript()->appendFile($this->moduleAsset()->moduleAssetUrl(Kitchensink_Model_Kitchensink::MODULE_NAME, 'app.js'));
```

## Testing the components

Components could be tested in storybook: `npm run storybook`.

## Using components

After developing the component and testing it in Storybook,
export the component from `App.tsx` with a meaningful name.
Everything that was exported from `App.tsx` will be accessible in browser as `kApps.Kitchensink`.
For instance, if the component was exported like `export const HelloWorld = () => <div>Hello, World!</div>;`,
then `kApps.Kitchensink.HelloWorld` will hold the reference to the component.

Pass the component as a property to the relevant PHP interface to render the component on the page.
Use `Zend_Json_Expr` if necessary to make sure that the reference to the component will not be JSON-encoded as a string,
e.g. `['component' => new Zend_Json_Expr('kApps.Kitchensink.HelloWorld')]`.
The encoding will happen automatically when using instances of `Kms_Type_Component`.

## Using components and utilities from DS

Install relevant DS packages with npm, and use them as usual.

## Using components and utilities from mediaspace-react-components

Install the npm packages that contains the necessary
components and utilities and use them as usual, e.g.

```cmd
npm install @kaltura/mediaspace-shared-layout @kaltura/mediaspace-shared-utils
```

```typescript jsx
import { HighContrastMenuItem } from "@kaltura/mediaspace-shared-layout";
import { translate } from "@kaltura/mediaspace-shared-layout";

export const MyComponent = () => <HighContrastMenuItem title={translate("High contrast")}/>;
```
