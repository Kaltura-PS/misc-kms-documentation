import { defineConfig } from "vite";
import { kmsViteConfig } from "./src/auto/vite-config";

export default defineConfig(kmsViteConfig("Kitchensink"));
