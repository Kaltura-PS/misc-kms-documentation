import { modifyStorybookPreview } from "../src/auto/storybook-preview";

export default modifyStorybookPreview({
    parameters: {
        actions: { argTypesRegex: "^on[A-Z].*" },
        controls: {
            matchers: {
                color: /(background|color)$/i,
                date: /Date$/i,
            },
        },
    },
});
