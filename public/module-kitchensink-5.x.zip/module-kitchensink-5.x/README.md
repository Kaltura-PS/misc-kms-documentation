# Kitchensink
This module's purpose is to provide examples for integrating DS-compatible React components
in MediaSpace.

(DS = Design System)

## You can find the implementation here:
### General
- Add a standalone page
- Add translations to the React app page
- Add DS layout to any page

### Media Page
- Add menu item into actions
- Add button to actions area
- Add metadata

### Channel Page
- Add tabs

### Profile Page
- Add tabs

### Upload/Edit Media Page
- Add files
- Save custom fields